Pasos para construir una API

- [Spring](https://start.spring.io/) Iniciar proyecto


1. Mapear las entidades
2. Crear las interface de CRUDrepository
3. Crear los DTOs
4. Crear los Mappers
5. Crear el repositorio del dominio
6. Creamos los metodos del repositorio de infraestructura, que interactua con la BD.
7. Creamos el Service
