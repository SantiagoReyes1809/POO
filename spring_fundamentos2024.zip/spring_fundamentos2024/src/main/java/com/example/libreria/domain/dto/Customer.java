package com.example.libreria.domain.dto;

public class Customer {
    
}
